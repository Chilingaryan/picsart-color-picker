# Instalation

yarn

# Run locally

yarn dev
